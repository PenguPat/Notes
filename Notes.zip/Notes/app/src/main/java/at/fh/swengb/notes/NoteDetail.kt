package at.fh.swengb.notes

import androidx.appcompat.app.AppCompatActivity
import android.os.Bundle

class NoteDetail : AppCompatActivity() {

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        setContentView(R.layout.activity_note_detail)
    }
}

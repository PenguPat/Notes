package at.fh.swengb.notes

import android.content.Context
import retrofit2.Call
import retrofit2.Callback
import retrofit2.Response

object NotesRepository {
    /*fun noteList(success: (noteList: NotesResponse) -> Unit, error: (errorMessage: String) -> Unit, response : String, response2 : Long)
    {
        NotesApi.retrofitService.notes(response, response2).enqueue(object : Callback<NotesResponse> {
            override fun onFailure(call: Call<NotesResponse>, t: Throwable) {
                error("The call failed")
            }

            override fun onResponse(
                call: Call<NotesResponse>,
                response: Response<NotesResponse>
            ) {
                val responseBody = response.body()
                if (response.isSuccessful && responseBody != null) {
                    success(responseBody)
                } else {
                    error("Something went wrong")
                }
            }

        })
    }*/
    fun login(success: (logintoken: AuthResponse) -> Unit, error: (errorMessage: String) -> Unit, request: AuthRequest)
    {
        NotesApi.retrofitService.login(request).enqueue(object : Callback<AuthResponse> {
            override fun onFailure(call: Call<AuthResponse>, t: Throwable) {
                error("Failed")
            }

            override fun onResponse(call: Call<AuthResponse>, response: Response<AuthResponse>) {
                val responseBody = response.body()
                if (response.isSuccessful && responseBody != null) {
                    success(responseBody)
                } else {
                    error("Ups,there is something wrong")
                }
            }

        })
    }
}

